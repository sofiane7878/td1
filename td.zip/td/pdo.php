<?php
//Infos de connexions
$host = 'mysql:host=localhost;dbname=td1';
$username = 'root';
$password = '';
//Tentative de connexion
try {   
    $pdo = new PDO($host, $username, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    echo "Il y a une erreur". $e->getMessage();
}




?>